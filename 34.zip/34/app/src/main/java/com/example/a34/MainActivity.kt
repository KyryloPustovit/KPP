package com.example.a34

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.graphics.Color
import android.view.View
import android.widget.TextView
import com.example.a34.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Додати обробники кліків для TextView
        binding.textViewInfo.setOnClickListener {
            changeTextColor(it as TextView)
        }

        binding.textViewGroup.setOnClickListener {
            changeTextColor(it as TextView)
        }

        binding.textViewCity.setOnClickListener {
            changeTextColor(it as TextView)
        }

        // Додати обробники для кнопок
        binding.buttonHide.setOnClickListener {
            binding.textViewInfo.visibility = View.GONE
        }

        binding.buttonShow.setOnClickListener {
            binding.textViewInfo.visibility = View.VISIBLE
        }
    }

    private fun changeTextColor(textView: TextView) {
        // Змінюємо колір тексту на випадковий
        textView.setTextColor(Color.rgb((0..255).random(), (0..255).random(), (0..255).random()))
    }
}